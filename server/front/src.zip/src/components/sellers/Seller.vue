<template>
<div>
  <div style="margin-bottom:50px;">
  <el-row>
  <el-col :xs="24" :sm="12" :md="16" :lg="12" :xl="14"><img src="../../assets/headpic.jpg"></el-col>
  <el-col :xs="8" :sm="3" :md="2" :lg="3" :xl="3">欢迎您!</el-col>
  <el-col :xs="8" :sm="3" :md="2" :lg="3" :xl="3">{{ $route.params.user }}</el-col>
  <el-button :xs="8" :sm="6" :md="4" :lg="6" :xl="4" icon="el-icon-bell" circle @click="onAvater"></el-button>
  <hr class="HR">
  </el-row>
  </div>
  <el-row>
        <el-col span="8">
  <div style="position:absolute;margin-left:5%;margin-bottom:20px;">
  <el-radio-group v-model="isCollapse" style="margin-bottom: 20px; " >
  <el-radio-button :label="false">展开</el-radio-button>
  <el-radio-button :label="true">收起</el-radio-button></el-radio-group>
  </div>
  <div style="margin-top:115px;">
<el-menu default-active="1-4-1" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose" :collapse="isCollapse">
  <el-menu-item index="1" @click="onQRcode">
      <i class="el-icon-mobile-phone"></i>
      <span slot="title">查看二维码</span>
  </el-menu-item>
  <el-menu-item index="2" @click="onSales">
    <i class="el-icon-document"></i>
    <span slot="title">查看业绩</span>
  </el-menu-item>
  <el-menu-item index="3" v-on:click="onPassword">
    <i class="el-icon-setting"></i>
    <span slot="title">修改密码</span>
  </el-menu-item>
</el-menu>
  </div>
        </el-col>
        <el-col span="16">
          <div span="16" style="height:700px" v-show="showpassword">
            <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" class="demo-ruleForm">
                <el-form-item label="旧密码" prop="oldpass">
                  <el-input type="password" v-model="ruleForm.oldpass" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="新密码" prop="newpass">
                  <el-input type="password" v-model="ruleForm.newpass" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="确认新密码" prop="checkpass">
                  <el-input type="password" v-model="ruleForm.checkpass" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
                <el-button @click= "resetForm('ruleForm')" >重置</el-button>
                </el-form-item>
              </el-form>
              </div>
              <div span="16" style="height:700px" v-show="showQRcode">
                  <el-button type="primary" icon="el-icon-search" @click="getQRcode">获取二维码</el-button>
                    <img scr=picture>
              </div>
              <div span="16" style="height:700px" v-show="showsales">
                <div class="block">
                    <span class="demonstration"></span>
                    <el-date-picker
                    v-model="value0"
                    type="datetimerange"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期"
                    :default-time="['12:00:00']">
                    </el-date-picker>
                     <el-button type="primary" icon="el-icon-search" @click="getSales">搜索</el-button>
              </div>
              <el-table :data="tableData" style="width: 80%">
                    <el-table-column prop="todayNum" label="今日客户数"></el-table-column>
                    <el-table-column prop="todayMoney" label="今日总销售额"></el-table-column>
                    <el-table-column prop="dateNum" label="已选日期总客户数"></el-table-column>
                    <el-table-column prop="dateMoney" label="已选日期总销售额"></el-table-column>
              </el-table>
            </div>
        </el-col>
  </el-row>
  </div>
</template>

<style>
    .grid-content {
        border-radius: 4px;
        min-height: 36px;
    }

    .el-menu-vertical-demo:not(.el-menu--collapse) {
        width: 200px;
        min-height: 400px;
    }

    .HR {
        margin-top: 2px;
        filter: alpha(opacity=100, finishopacity=0, style=3);
        width: 85%;
        color: #987cb9;
        size: 3;
    }
    .el-form
    {
        margin-top:80px;
        margin-right: 30%;
    }
</style>
<script>
    import Vue from 'vue'
    import {getCookie} from '@/utils/utils'
    
    export default {
        data() {
        var validatenewPass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入新密码'));
        } else {
          if (this.ruleForm.newpass !== '') {
            this.$refs.ruleForm.validateField('newpass');
          }
          callback();
        }
      };
      var validatenewPass2 = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请再次输入新密码'));
        } else if (value !== this.ruleForm.newpass) {
          callback(new Error('两次输入密码不一致!'));
        } else {
          callback();
        }
      };
        return {
                isCollapse: true,
                showpassword:false,
                showQRcode:false,
                showsales:false,
                value0:'',
                tableData:[],
                name: this.$route.params.user,
                ruleForm:{
                    newpass:'',
                    checkpass:'',
                    csrf: getCookie('csrftoken'),
                },
                rules: {
                    newpass: [
                        { validator: validatenewPass, trigger: 'blur' }
                    ],
                    checkpass:[
                        { validator: validatenewPass2, trigger: 'blur' }
                    ]
                }
            };
    },
        methods: {
            handleOpen(key, keyPath) {
                console.log(key, keyPath);
            },
            handleClose(key, keyPath) {
                console.log(key, keyPath);
            },
            onAvater() {
            },
            onQRcode() {
                this.showpassword=false;
                this.showQRcode=true;
                this.showsales=false;
            },
            onSales() {
                this.showpassword=false;
                this.showsales=true;
                this.showQRcode=false;
            },
            onPassword() {
                this.showQRcode=false;
                this.showpassword=true;
                this.showsales=false;
            },
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                if (valid) {
                    alert('submit!');
                } else {
                    console.log('error submit!!');
                    return false;
                }
                });
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
            },
            getQRcode: function() {
                this.axios({
                    method: 'post',
                    url: 'api/post_test',
                    data: {
                        'name': this.name
                    },
                    headers: {"X-CSRFToken": getCookie('csrftoken')},
                    }).then(function(response){
                        picture=response.data.picsrc;
                    })            
            },
            getSales: function() {
                    this.axios({
                        method: 'post',
                        url: 'api/post_test',
                        data: {
                            datetimerange:value0,
                            'name': this.name
                        },
                        headers: {"X-CSRFToken": getCookie('csrftoken')},
                    }).then(function(response){
                        this.tableData=response.data;
                    })            
                }
        }
    };
</script>