<template>
  <div>
    <div class="image">
      <img src="../../assets/headpic.jpg">
    </div>
    <h1><strong>弈学园后台管理系统</strong></h1>
    <div class="tabs">
      <el-tabs v-model="activeName" :tab-position="tabPosition" class="formu">
        <el-tab-pane label="地推人员" name="5">
          <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2"
          label-width="100px" class="demo-ruleForm">
            <br>
            <el-form-item label="用户名" prop="user" label-width="80px">
              <el-input style="width:250px;" v-model.number="ruleForm2.user"
              auto-complete="on" placeholder="请输入用户名"></el-input>
            </el-form-item>
            <el-form-item label="密码" prop="pass" label-width="80px">
              <el-input style="width:250px;" type="password" v-model="ruleForm2.pass"
              auto-complete="off" placeholder="请输入密码"></el-input>
            </el-form-item>
            <el-row :gutter="20">
              <el-col :span="6" :offset="2"><el-checkbox>记住我</el-checkbox></el-col>
              <el-col :span="8" :offset="7"><a href="">忘记密码？</a></el-col>
            </el-row>
            <el-form-item class="item">
              <el-button type="primary" @click="submitForm('ruleForm2')">登录</el-button>
              <el-button @click="resetForm('ruleForm2')">重置</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
        <el-tab-pane label="课程顾问" name="3">
          <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2"
          label-width="100px" class="demo-ruleForm">
            <br>
            <el-form-item label="用户名" prop="user" label-width="80px">
              <el-input style="width:250px;" v-model.number="ruleForm2.user"
              auto-complete="on" placeholder="请输入用户名"></el-input>
            </el-form-item>
            <el-form-item label="密码" prop="pass" label-width="80px">
              <el-input style="width:250px;" type="password" v-model="ruleForm2.pass"
              auto-complete="off" placeholder="请输入密码"></el-input>
            </el-form-item>
            <el-row :gutter="20">
              <el-col :span="6" :offset="2"><el-checkbox>记住我</el-checkbox></el-col>
              <el-col :span="8" :offset="7"><a href="">忘记密码？</a></el-col>
            </el-row>
            <el-form-item class="item">
              <el-button type="primary" @click="submitForm('ruleForm2')">登录</el-button>
              <el-button @click="resetForm('ruleForm2')">重置</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
        <el-tab-pane label="教务老师" name="4">
          <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2"
          label-width="100px" class="demo-ruleForm">
            <br>
            <el-form-item label="用户名" prop="user" label-width="80px">
              <el-input style="width:250px;" v-model.number="ruleForm2.user"
              auto-complete="on" placeholder="请输入用户名"></el-input>
            </el-form-item>
            <el-form-item label="密码" prop="pass" label-width="80px">
              <el-input style="width:250px;" type="password" v-model="ruleForm2.pass"
              auto-complete="off" placeholder="请输入密码"></el-input>
            </el-form-item>
            <el-row :gutter="20">
              <el-col :span="6" :offset="2"><el-checkbox>记住我</el-checkbox></el-col>
              <el-col :span="8" :offset="7"><a href="">忘记密码？</a></el-col>
            </el-row>
            <el-form-item class="item">
              <el-button type="primary" @click="submitForm('ruleForm2')">登录</el-button>
              <el-button @click="resetForm('ruleForm2')">重置</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
        <el-tab-pane label="超级管理员" name="1">
          <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2"
          label-width="100px" class="demo-ruleForm">
            <br>
            <el-form-item label="用户名" prop="user" label-width="80px">
              <el-input style="width:250px;" v-model.number="ruleForm2.user"
              auto-complete="on" placeholder="请输入用户名"></el-input>
            </el-form-item>
            <el-form-item label="密码" prop="pass" label-width="80px">
              <el-input style="width:250px;" type="password" v-model="ruleForm2.pass"
              auto-complete="off" placeholder="请输入密码"></el-input>
            </el-form-item>
            <el-row :gutter="20">
              <el-col :span="6" :offset="2"><el-checkbox>记住我</el-checkbox></el-col>
              <el-col :span="8" :offset="7"><a href="">忘记密码？</a></el-col>
            </el-row>
            <el-form-item class="item">
              <el-button type="primary" @click="submitForm('ruleForm2')">登录</el-button>
              <el-button @click="resetForm('ruleForm2')">重置</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
import { getCookie } from '@/utils/utils';

export default {
  data() {
    const validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'));
      } else {
        callback();
      }
    };
    const validateUser = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入用户名'));
      } else {
        callback();
      }
    };
    return {
      tabPosition: 'top',
      activeName: '5',
      csrf: getCookie('csrftoken'),
      ruleForm2: {
        user: '',
        pass: '',
      },
      rules2: {
        pass: [
          { validator: validatePass, trigger: 'blur' },
        ],
        user: [
          { validator: validateUser, trigger: 'blur' },
        ],
      },
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.axios({
            method: 'post',
            url: 'api/login',
            data: {
              type: this.activeName,
              user: this.ruleForm2.user,
              password: this.ruleForm2.pass,
            },
            headers: { 'X-CSRFToken': getCookie('csrftoken') },
          }).then((response) => {
            if ((response.data.success === 0 && response.data.error === 0)) {
              this.$alert('用户名或密码错误', '警告', {
                confirmButtonText: '确定',
                callback: () => {
                  this.$message({
                    type: 'info',
                    message: '注意修改用户名或密码哦！',
                  });
                },
              });
            } else if (response.data.success === 0 && response.data.error === 1) {
              this.$alert('身份信息不匹配', '警告', {
                confirmButtonText: '确定',
                callback: () => {
                  this.$message({
                    type: 'info',
                    message: '注意选择合适的身份信息哦！',
                  });
                },
              });
            } else if (this.activeName === '5') {
              this.$router.push({ name: 'Seller', params: { user: this.ruleForm2.user } });
            } else if (this.activeName === '4') {
              this.$router.push({ name: 'HelloWorld', params: { user: this.ruleForm2.user } });
            } else if (this.activeName === '3') {
              this.$router.push({ name: 'HelloWorld', params: { user: this.ruleForm2.user } });
            } else {
              this.$router.push({ name: 'HelloWorld', params: { user: this.ruleForm2.user } });
            }
          });
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h3 {
  font-weight: normal;
  margin-left: 180px;
  margin-top: 150px;
  color: rgba(0, 110, 255, 0.973);
  font-family: "微软雅黑";
}
a {
  color: #42b983;
}
.home {
  background-color: rgba(0, 110, 255, 0.973);
  color: white;
}
.formu {
  background-color: rgba(128, 128, 128, 0.1);
  border-width: 1px;
  border-color: rgba(128, 128, 128, 0.3);
  border-style: solid;
  padding-left: 20px;
  padding-right: 10px;
  padding-top: 20px;
  padding-bottom: 20px;
}
.tabs {
  position: relative;
  left: 250px;
  top: -180px;
  margin: 0 auto;
  width: 410px;
}
.image {
  position: relative;
  margin: 20px;
  left: 100px;
  top: 10px;
}
.item {
  margin-top: 25px;
}
</style>
