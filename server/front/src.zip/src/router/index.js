import Vue from 'vue';
import Router from 'vue-router';
import Login from '@/components/BackLogin/Login';
import Seller from '@/components/sellers/Seller';


Vue.use(Router);

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Login',
      component: Login,
    },
    {
      path: '/Seller',
      name: 'Seller',
      component: Seller,
    },
  ],
});
